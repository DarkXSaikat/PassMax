## To be released

### Features :tada:

### Fixes :bug:

### Other

## 1.41.4 (2026-10-14)

### Fixes :bug:

- Bug fixes and improvements.

## 1.41.3 (2026-10-05)

### Fixes :bug:

- Fixed biometric unlock reporting an enrollment change when no biometric was enrolled.

## 1.41.2 (2026-09-28)

### Fixes :bug:

- Bug fixes and improvements.

## 1.41.1 (2026-09-25)

### Fixes :bug:

- Bug fixes and improvements.

## 1.41.0 (2026-09-22)

### Fixes :bug:

- Improved security around autofill and passkeys.
- Fixed several sync and search issues.
- General bug fixes and improvements.

## 1.40.3 (2026-07-28)

### Fixes :bug:

- Fix sync issue due to logout.

## 1.40.2 (2026-07-08)

### Fixes :bug:

- Fix a Passkey race condition.

## 1.40.1 (2026-06-29)

### Fixes :bug:

- Bug fixes and improvements.

## 1.40.0 (2026-06-10)

### Features :tada:

- Improved synchronization.

### Fixes :bug:

- Bug fixes and improvements.

### Other

- Updated translations.

## 1.39.2 (2026-04-23)

### Fixes :bug:

- Bug fixes and improvements.

## 1.39.1 (2026-04-15)

### Fixes :bug:

- Bug fixes and improvements.

## 1.39.0 (2026-04-10)

### Features :tada:

- Allow user to choose between inline and popup autofill.
- Allow user to disable autosave on Android.
- Highlight links in notes and allow opening them.
- Add clear log option in log screen.

### Fixes :bug:

- Fix items from all accounts showing in autofill extension regardless of user settings.
- Fix crash when adding a second date in an Identity section.
- Improve QR code detection.

### Other

- Updated translations.

## 1.38.0 (2026-03-12)

### Features :tada:

- Allow generating SSH key pairs within SSH key items.
- Improved autosave.

### Fixes :bug:

- Bug fixes and improvements.

### Other

- Add view alias from login.
- Updated translations.

## 1.37.3 (2026-03-09)

### Fixes :bug:

- Bug fixes and improvements.

## 1.37.2 (2026-02-12)

### Fixes :bug:

- Pass lifetime sharing.
- Enable Meta Quest autofill.

## 1.37.1 (2026-02-05)
`
### Fixes :bug:

- Bug fixes and improvements.

## 1.37.0 (2026-01-26)

### Features :tada:

- Update upgrade screen design.

### Fixes :bug:

- Fix upgrade in credit card detail.
- Autofill and Passkeys improvements.
- Other bug fixes and improvements.

### Other

- Updated translations.

## 1.36.5 (2026-01-14)

### Fixes :bug:

- Fix redirection url in Meta Horizon

## 1.36.4 (2025-12-17)

### Fixes :bug:

- Disable autofill in Meta Horizon
- Disable biometric in Meta Horizon

### Other

## 1.36.3 (2025-12-10)

### Fixes :bug:

- Autofill with multiaccount

## 1.36.2 (2025-12-04)

### Other

- Update link.

## 1.36.1 (2025-12-01)

### Fixes :bug:

- Meta Horizon release.

## 1.36.0 (2025-11-25)

### Features :tada:

- Password history.

### Fixes :bug:

- Bug fixes and improvements.

## 1.35.1 (2025-11-21)

### Fixes :bug:

- Bug fixes and improvements.

## 1.35.0 (2025-11-18)

### Fixes :bug:

- Bug fixes and improvements.

### Other

- Show warning when a user creates/edits an item in a shared vault or move an item to a shared vault.
- Updated translations.

## 1.34.2 (2025-11-13)

### Other

- Remove not supported permissions from Quest.

## 1.34.1 (2025-11-12)

### Other

- Add Meta Quest support.

## 1.34.0 (2025-10-24)

### Other

- Support new promo messages.
- Improved passkeys compatibility and support for PRF.
- Updated translations.

## 1.33.1 (2025-10-13)

### Fixes :bug:

- Use Passkeys with qr.

## 1.33.0 (2025-10-01)

### Features :tada:

- Option to duplicate item.

### Fixes :bug:

- Bug fixes and improvements.

### Other

- Updated translations.
- Updated core libraries.

## 1.32.7 (2025-07-23)

### Fixes :bug:

- Bug fixes and improvements.

## 1.32.6 (2025-07-03)

### Fixes :bug:

- Bug fixes and improvements.

## 1.32.5 (2025-07-02)

### Fixes :bug:

- Bug fixes and improvements.

## 1.32.4 (2025-07-01)

### Fixes :bug:

- Bug fixes and improvements.

## 1.32.3 (2025-06-30)

### Fixes :bug:

- Bug fixes and improvements.

## 1.32.2 (2025-06-27)

### Fixes :bug:

- Bug fixes and improvements.

## 1.32.1 (2025-06-19)

### Fixes :bug:

- Bug fixes and improvements.

## 1.32.0 (2025-06-18)

### Features :tada:

- Integrate password sign in with Credential Manager

### Other

- Updated translations.
- Updated core libraries.

## 1.31.4 (2025-06-11)

### Fixes :bug:

- Autofill and autosave improvements.

## 1.31.3 (2025-05-09)

### Fixes :bug:

- PIN code input improvements.
- Autofill improvements.

### Other

- Make Identity SSN field hidden.
- UI tweaks.
- Updated translations.

## 1.31.2 (2025-04-11)

### Fixes :bug:

- Internal bugfixes

## 1.31.1 (2025-04-11)

### Fixes :bug:

- Internal bugfixes

## 1.31.0 (2025-04-09)

### Fixes :bug:

- Internal fixes.

## 1.30.6 (2025-04-04)

### Fixes :bug:

- Bug fixes and improvements.

## 1.30.5 (2025-03-26)

### Fixes :bug:

- Bug fixes and improvements.

## 1.30.4 (2025-03-25)

### Fixes :bug:

- Bug fixes and improvements.

## 1.30.3 (2025-03-24)

### Fixes :bug:

- Fix custom fields in login items.
- Fix custom fields during autosave.

## 1.30.2 (2025-03-21)

### Fixes :bug:

- Bug fixes and improvements.

### Other

- Support per-app language preference.
- Updated translations.
- Updated core libraries.

## 1.30.1 (2025-03-07)

### Fixes :bug:

- Allow spaces on login username.
- Bug fixes and improvements.

### Other

- Updated translations.

## 1.30.0 (2025-02-14)

### Features :tada:

- User can change mailbox email.

### Fixes :bug:

- Screen closing on maximum pin attempts.

### Other

- Updated translations.

## 1.29.1 (2025-01-20)

### Fixes :bug:

- Infinite loading on accepting empty vault invite

## 1.29.0 (2025-01-24)

### Features :tada:

- Add reset history option.

### Fixes :bug:

- Allow adding multiple Pass lifetime accounts.

### Other

- Add toggle to disable improved autofill.
- Updated translations.
- Updated core libraries.

## 1.28.6 (2024-12-19)

### Fixes :bug:

- Bug fixes.

## 1.28.5 (2024-12-17)

### Fixes :bug:

- Bug fixes.

## 1.28.4 (2024-12-16)

### Fixes :bug:

- Bug fixes.

## 1.28.3 (2024-12-13)

### Fixes :bug:

- Fix incorrect password score during password generation.
- Update common library for passkeys improvements

## 1.28.2 (2024-11-26)

### Fixes :bug:

- Bug fixes.

## 1.28.1 (2024-11-25)

### Other

- Improve autofill.

## 1.28.0 (2024-11-22)

### Features :tada:

- Advanced alias management.
- Support not primary accounts management.

### Other

- UI tweaks to improve internationalization support.
- Updated translations.

## 1.27.1 (2024-11-11)

### Fixes :bug:

- Incorrect display of sync dialog.

## 1.27.0 (2024-11-08)

### Features :tada:

- Item count redirects to items list.

### Fixes :bug:

- Avoid items loading delay on the home screen.
- Credit card expiration date history.

### Other

- UI tweaks in the password generator.
- Performance improvements.
- Exclude items with passkeys from missing 2FA check.
- Updated core libraries.
- Updated translations.

## 1.26.3 (2024-11-06)

### Other

- Add SL aliases permanent removal warning.

## 1.26.2 (2024-10-25)

### Fixes :bug:

- Passkey creation with multiaccount.
- Autofill on old Android versions.
- Improved autofill compatibility with third-party keyboards

### Other

- Add option to see pinned items during autofill.
- SL note sync.
- Some performance improvements.
- Updated translations.

## 1.26.1 (2024-10-14)

### Fixes :bug:

- Autofill crash with an alias.

## 1.26.0 (2024-10-11)

### Features :tada:

- Support multi-account autofill.
- Username field always display setting.

### Fixes :bug:

- Fixes on autofill.
- Fixed login items options.
- Fixed crash on secure links fetching.

### Other

- Improved username/email fields input behavior.
- Updated translations.

## 1.25.1 (2024-09-26)

### Fixes :bug:

- Bug fixes and improvements.

## 1.25.0 (2024-09-20)

### Features :tada:

- Revamped report screen
- Add new reset filters option

### Fixes :bug:

- Fixed alias detachment

### Other

- Select last used vault as default vault
- Updated translations.
- Updated core libraries.

## 1.24.6 (2024-08-29)

### Fixes :bug:

- Issues when login with two-factor authentication.

### Other

- Updated translations.

## 1.24.5 (2024-08-29)

### Fixes :bug:

- Issues when login with two-factor authentication.

### Other

- Updated translations.

## 1.24.4 (2024-08-13)

### Fixes :bug:

- Crashes when editing an identity custom section.

## 1.24.3 (2024-08-12)

### Fixes :bug:

- Crashes when removing an identity custom field.

## 1.24.2 (2024-08-08)

### Features :tada:

- Autofill improvements.

### Fixes :bug:

- Extra password getting stuck during login.

### Other

- Updated translations.
- Updated dependencies.

## 1.24.1 (2024-07-25)

### Fixes :bug:

- Fix linked apps item revision diffing.
- Fix sharing trashed item.
- Fix extra password crash.

### Other

- Updated core libraries.

## 1.24.0 (2024-07-19)

### Features :tada:

- History item revisions diffing.

### Fixes :bug:

- Improved item syncing.
- Fixed migrated items secure links syncing.
- Improved passkey domain matching.
- Avoid username field auto-clear when attaching an alias.
- Improved user auth flow security.
- Solved formatted date display issues for some locales.
- UI tweaks.

### Other

- Updated core libraries.
- Updated translations.

## 1.23.2 (2024-07-04)

### Fixes :bug:

- Bug fixes and improvements.

## 1.23.1 (2024-07-03)

### Fixes :bug:

- Bug fixes and improvements.

## 1.23.0 (2024-06-27)

### Fixes :bug:

- Sync issues on password reset.
- Pinned items incorrect counting.
- Fixes Custom fields not opening.
- Improves clear clipboard.
- Other bug fixes and improvements.

### Other

- Improve note scrolling.
- Updated translations.

## 1.22.1 (2024-06-10)

### Fixes :bug:

- Bug fixes

## 1.22.0 (2024-06-07)

### Fixes :bug:

- Alias mailboxes selector.
- Photo picker crash.
- React to sync errors on the UI

### Other

- Updated core libraries.
- Updated translations.

## 1.21.4 (2024-05-22)

### Fixes :bug:

- Logout crashes.
- Pass monitor fixes and improvements.
- Autofill multistep improvements.
- Sync improvements.

### Other

- Vault switcher redesign.
- Create credit card shortcut on empty vault.
- Extend lock period if user is active.
- Updated translations.

## 1.21.3 (2024-05-06)

### Features :tada:

- FDroid releases now don't bundle any telemetry library.

### Fixes :bug:

- Pass monitor fixes and improvements.

### Other

- Updated translations

## 1.21.2 (2024-05-03)

### Fixes :bug:

- Pass monitor fixes and improvements.

## 1.21.1 (2024-04-30)

### Fixes :bug:

- Crash in Dark web monitor screen.

## 1.21.0 (2024-04-30)

### Features :tada:

- Include Pass Monitor.
- Do not include sentry in FDroid builds.

### Fixes :bug:

- Allow to select an alias suffix when there are many suffixes to pick from.

### Other

- Allow to delete data when logging out.
- Updated core libraries.
- Updated translations.

## 1.20.4 (2024-04-12)

### Fixes :bug:

- Do not strip ports and paths when storing a URL.
- FDroid build issues.

### Other

- Updated translations.

## 1.20.3 (2024-04-05)

### Features :tada:

- Improve passkey compatibility for QR-based flows.

### Fixes :bug:

- In some ocasions the app could show the trash options when accessing the app.
- Crashes when autofilling a newly created alias.
- Crashes when trying to add a passkey created by some apps.

### Other

- Updated translations.

## 1.20.2 (2024-03-27)

### Features :tada:

- Improve passkey compatibility.

### Fixes :bug:

- Crash on some sync issue failures.

### Other

- Updated translations.

## 1.20.1 (2024-03-25)

### Features :tada:

- Improve passkey compatibility.
- Add passkey support indicator.

### Fixes :bug:

- Show full passkey key id in the details screen.

### Other

- Updated translations.
- Updated dependencies.

## 1.20.0 (2024-03-21)

### Features :tada:

- Enable passkey support.

## 1.19.0 (2024-03-15)

### Features :tada:

- Performance improvements in the app's responsiveness.
- Improved error handling when trying to share a vault.

### Fixes :bug:

- Autofill will not try to autofill the "password" field of Proton Pass.
- Autofill will not ask for association if the website was already linked to the item.
- Fixed a bug where sometimes the main list was not displaying the items.

### Other

- Updated translations.
- Updated dependencies.

## 1.18.3 (2024-03-01)

### Fixes :bug:

- Bug in edit login that did not allow to remove a linked app.
- Remaining invite count sometimes didn't reflect the updated number.

### Other

- Add better support for future item attributes.
- Updated translations.

## 1.18.2 (2024-02-26)

### Fixes :bug:

- Bug in custom fields that duplicated them when editing.

## 1.18.1 (2024-02-19)

### Fixes :bug:

- Autofill item selection crash.

## 1.18.0 (2024-02-19)

### Features :tada:

- Improved sync resiliency.
- Smooth UI animations for TOTP codes.

### Fixes :bug:

- Forced sync not removing old items.
- Incorrect warning when moving an item between vaults.
- Some UI issues.

### Other

- Updated translations.

## 1.17.0 (2024-01-26)

### Features :tada:

- Invite multiple addresses during sharing.
- Email suggestions during sharing.

### Fixes :bug:

- Fix bottomsheet overlay incorrect behaviour.
- 2FA not being displayed for a free account.

### Other

- Persist user filtering preference.
- Increase default password length to 20.
- User can pin from the home screen.

## 1.16.4 (2024-01-23)

### Other

- Add more logging to investigate deadlock.

## 1.16.3 (2024-01-19)

### Other

- Add tutorial link to onboarding.

## 1.16.2 (2024-01-19)

### Other

- Add manage account link.
- Add tutorial link.

## 1.16.1 (2024-01-17)

### Fixes :bug:

- Fix pinning issues.

## 1.16.0 (2024-01-17)

### Features :tada:

- Item pinning.
- Add adaptive icon.

### Fixes :bug:

- Item count mismatch between the search and the filters.

### Other

- Add monospace font to the password and otp fields.
- Support custom field search.
- Change CC expiration date format to YY.
- Updated translations.

## 1.15.4 (2024-01-08)

### Fixes :bug:

- Add timeout to avoid leaving worker locked.

## 1.15.3 (2024-01-05)

### Fixes :bug:

- Fix external account invites.

## 1.15.2 (2024-01-05)

### Fixes :bug:

- Fixed PIN code bottom sheet behaviour when device orientation changes.
- Do not allow read only items being moved to trash.

### Other

- Onboarding tips improvements.
- Improved Alias title on Alias creation.
- Updated translations.

## 1.15.1 (2023-12-27)

### Fixes :bug:

- Fix autofill suggestions for Chromium based browsers

## 1.15.0 (2023-12-22)

### Features :tada:

- Added password strength indicator.
- Added share logs shortcut.

### Other

- Updated translations.

## 1.14.2 (2023-12-19)

### Features :tada:

- Improve UX when autofilling credentials in potentially dangerous contexts.

### Other

- Update translations.
- Update dependencies.

## 1.14.1 (2023-12-12)

### Fixes :bug:

- Fix error on user invite

## 1.14.0 (2023-12-12)

### Features :tada:

- Bulk actions
- Display shared icons in Vault chooser list.

## 1.13.1 (2023-12-04)

### Fixes :bug:

- Crash on some devices when opening the app.

## 1.13.0 (2023-12-01)

### Features :tada:

- Add a default vault selector in the Settings screen.
- Add a new 3-dot menu in the main list.

### Fixes :bug:

- Item details not showing properly on some languages.
- Crash when editing custom fields.

### Other

- Autofill improvements.
- Update translations.
- Warning if the default browser doesn't support autofill.

## 1.12.0 (2023-11-24)

### Other

- Search improvements.
- Autofill improvements.
- Update translations.

## 1.11.2 (2023-11-22)

### Fixes :bug:

- Autofill crash on some devices.

## 1.11.1 (2023-11-22)

### Fixes :bug:

- Stability fixes regarding custom fields.

### Other

- Autofill improvements.

## 1.11.0 (2023-11-17)

### Features :tada:

- Password scorer in item detail.

### Fixes :bug:

- Stability fixes.

### Other

- Improve autofill and autosave.
- Update translations.

## 1.10.4 (2023-11-15)

### Fixes :bug:

- Make camera not mandatory to install the app.
- Don't disable autofill on user logout.

### Other

- Improve autofill

## 1.10.3 (2023-11-13)

### Fixes :bug:

- View Alias from Login detail screen.

## 1.10.2 (2023-11-13)

### Fixes :bug:

- Crash on Regex used by autofill.

## 1.10.1 (2023-11-13)

### Fixes :bug:

- Crash on wrong TOTP code from autofill.
- Change PIN button.

### Other

- Improve autofill

## 1.10.0 (2023-11-10)

### Features :tada:

- Improved share item from detail

### Fixes :bug:

- Fix item actions in trash view

### Other

- Improve autofill
- Add DuckDuckGo to browser list

## 1.9.6 (2023-10-27)

### Features :tada:

- Allow to share from item detail.
- New password generation implementation.

### Fixes :bug:

- Vault sharing not available in some cases.
- Improve error messages when an invite cannot be accepted.

### Other

- Updated translations.

## 1.9.5 (2023-10-24)

### Features :tada:

- Get sharing ready.

### Fixes :bug:

- Refresh plan details on app startup.
- Improve email validation.

### Other

- Updated translations.

## 1.9.4 (2023-10-17)

### Fixes :bug:

- Used the right address when the user has more than one address.

### Other

- Updated translations.

## 1.9.3 (2023-10-13)

### Other

- Wording in some screens.

## 1.9.2 (2023-10-10)

### Fixes :bug:

- Alias mailboxes can be edited again.

### Other

- Updated translations.

## 1.9.1 (2023-10-06)

### Features :tada:

- Add context to cryptographic signatures.

### Other

- Updated dependencies.

## 1.9.0 (2023-10-03)

### Features :tada:

- Allow to copy note contents to clipboard from note detail screen.
- Use the new common library for validations.
- Improved scroll responsiveness.

### Fixes :bug:

- Display proper plan name in the account screen.
- Home screen getting stuck on account creation.

### Other

- Updated translations.
- Updated dependencies.

## 1.8.3 (2023-09-08)

### Fixes :bug:

- Crash when clearing the clipboard on some devices.
- Crash when disabling autofill on older devices.

## 1.8.2 (2023-09-07)

### Fixes :bug:

- Search on long notes.
- Updating the vault name in another client now gets reflected on Android.
- Improved username detection in autofill.
- Fixed compatibility with 2FA codes stored in other clients.
- Clearing the clipboard after some time.
- Other minor bugfixes and improvements.

### Other

- Updated translations.

## 1.8.1 (2023-08-30)

### Features :tada:

- Add button to re-enter PIN / biometry in the Master password screen.

### Fixes :bug:

- Crash on Autosave.

### Other

## 1.8.0 (2023-08-29)

### Features :tada:

- Improved the app responsiveness while writing.
- Improved the item sync and initial item download with a new UI.

### Fixes :bug:

- 2FA QR scanner now detects the TOTP data properly.

### Other

- Updated translations
