/*
 * Copyright (c) 2023-2026 Proton AG
 * This file is part of Proton AG and Proton Pass.
 *
 * Proton Pass is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Proton Pass is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Proton Pass.  If not, see <https://www.gnu.org/licenses/>.
 */

package proton.android.pass.autofill.e2e.ui

import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import proton.android.pass.autofill.e2e.ui.main.MAIN_ROUTE
import proton.android.pass.autofill.e2e.ui.main.MainScreen
import proton.android.pass.autofill.e2e.ui.session.SESSION_DETAIL_ARG_NAME
import proton.android.pass.autofill.e2e.ui.session.SESSION_DETAIL_ROUTE
import proton.android.pass.autofill.e2e.ui.session.SessionScreen
import proton.android.pass.autofill.e2e.ui.sessions.SESSIONS_ROUTE
import proton.android.pass.autofill.e2e.ui.sessions.SessionsScreen

fun NavGraphBuilder.e2eAppGraph(navigator: NavHostController) {
    composable(MAIN_ROUTE) {
        MainScreen(
            onViewSessions = {
                navigator.navigate(SESSIONS_ROUTE)
            }
        )
    }

    composable(SESSIONS_ROUTE) {
        SessionsScreen(
            onSessionClick = {
                navigator.navigate("$SESSION_DETAIL_ROUTE/${it.filename}")
            }
        )
    }

    composable("$SESSION_DETAIL_ROUTE/{$SESSION_DETAIL_ARG_NAME}") {
        SessionScreen()
    }
}
