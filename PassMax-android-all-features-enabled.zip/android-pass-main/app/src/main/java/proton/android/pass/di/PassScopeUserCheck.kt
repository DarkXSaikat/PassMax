/*
 * Copyright (c) 2024-2026 Proton AG
 * This file is part of Proton AG and Proton Pass.
 *
 * Proton Pass is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Proton Pass is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Proton Pass.  If not, see <https://www.gnu.org/licenses/>.
 */

package proton.android.pass.di

import android.content.Context
import android.content.Intent
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.firstOrNull
import me.proton.core.account.domain.entity.AccountState
import me.proton.core.accountmanager.domain.AccountManager
import me.proton.core.accountmanager.domain.SessionManager
import me.proton.core.accountmanager.domain.getAccounts
import me.proton.core.auth.domain.usecase.PostLoginAccountSetup
import me.proton.core.auth.presentation.DefaultUserCheck
import me.proton.core.domain.entity.UserId
import me.proton.core.user.domain.UserManager
import me.proton.core.user.domain.entity.User
import me.proton.core.user.domain.extension.hasSubscription
import proton.android.pass.ForegroundActivityTracker
import proton.android.pass.R
import proton.android.pass.data.api.usecases.extrapassword.AuthWithExtraPasswordListener
import proton.android.pass.data.api.usecases.extrapassword.AuthWithExtraPasswordResult
import proton.android.pass.enterextrapassword.EnterExtraPasswordActivity
import proton.android.pass.log.api.PassLogger
import javax.inject.Inject

class PassScopeUserCheck @Inject constructor(
    private val accountManager: AccountManager,
    private val sessionManager: SessionManager,
    private val authWithExtraPasswordListener: AuthWithExtraPasswordListener,
    private val foregroundActivityTracker: ForegroundActivityTracker,
    @ApplicationContext private val context: Context,
    private val userManager: UserManager
) : DefaultUserCheck(context, accountManager, userManager) {
    override suspend fun invoke(user: User): PostLoginAccountSetup.UserCheckResult =
        when (val superResult = super.invoke(user)) {
            is PostLoginAccountSetup.UserCheckResult.Success -> {
                when (val passScopeResult = checkPassScope(user, authWithExtraPasswordListener)) {
                    is PostLoginAccountSetup.UserCheckResult.Success -> performAdditionalChecks(user)
                    else -> passScopeResult
                }
            }

            else -> superResult
        }

    private suspend fun checkPassScope(
        user: User,
        authWithExtraPasswordListener: AuthWithExtraPasswordListener
    ): PostLoginAccountSetup.UserCheckResult {
        val account = accountManager.getAccount(user.userId).firstOrNull()
            ?: return PostLoginAccountSetup.UserCheckResult.Error(
                context.getString(R.string.no_account_found)
            )
        val session = sessionManager.getSession(account.sessionId)
            ?: return PostLoginAccountSetup.UserCheckResult.Error(
                context.getString(R.string.no_session_found)
            )

        return if (session.scopes.contains(PASS_SCOPE)) {
            PostLoginAccountSetup.UserCheckResult.Success
        } else {
            PassLogger.i(TAG, "Waiting for extra password to be ready")

            authWithExtraPasswordListener.clearUserId(user.userId)
            startEnterExtraPassword(user.userId)

            val res = authWithExtraPasswordListener.onAuthWithExtraPassword(user.userId)
            authWithExtraPasswordListener.clearUserId(user.userId)
            PassLogger.i(TAG, "Auth with extra password listener: $res")
            when (res) {
                AuthWithExtraPasswordResult.Failure -> {
                    PostLoginAccountSetup.UserCheckResult.Error(
                        context.getString(R.string.auth_with_extra_password_failed)
                    )
                }

                AuthWithExtraPasswordResult.Success -> {
                    PostLoginAccountSetup.UserCheckResult.Success
                }
            }
        }
    }

    private fun startEnterExtraPassword(userId: UserId) {
        val intent = Intent(context, EnterExtraPasswordActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra(EnterExtraPasswordActivity.EXTRA_USER_ID, userId.id)
        }
        val activity = foregroundActivityTracker.launchSourceActivity
        if (activity != null) {
            activity.startActivity(intent)
        } else {
            PassLogger.i(TAG, "No activity to launch from, starting extra password in a new task")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }
    }

    private suspend fun performAdditionalChecks(user: User): PostLoginAccountSetup.UserCheckResult = when {
        currentFreeUserCount() >= 1 && user.isFreeUser() -> PostLoginAccountSetup.UserCheckResult.Error(
            context.getString(R.string.auth_only_1_proton_account_failed)
        )
        else -> PostLoginAccountSetup.UserCheckResult.Success
    }

    private suspend fun currentFreeUserCount(): Int = accountManager.getAccounts(AccountState.Ready).first()
        .map { userManager.getUser(it.userId) }
        .fold(0) { acc, user ->
            if (user.isFreeUser()) {
                acc + 1
            } else {
                acc
            }
        }

    private fun User.isFreeUser(): Boolean {
        val hasPassLifetime = this.flags.hasFlag(UserFlag.PASS_LIFETIME)
        val isPassFromSL = this.flags.hasFlag(UserFlag.PASS_FROM_SL)
        return !this.hasSubscription() && !hasPassLifetime && !isPassFromSL
    }

    private fun Map<String, Boolean>.hasFlag(flag: UserFlag): Boolean = this[flag.key] ?: false

    private enum class UserFlag(val key: String) {
        PASS_LIFETIME("pass-lifetime"),
        PASS_FROM_SL("pass-from-sl")
    }

    companion object {
        private const val TAG = "PassScopeUserCheck"
        private const val PASS_SCOPE = "pass"
    }
}
